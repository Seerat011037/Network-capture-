Place your exported network_capture.pcap file in this folder.
